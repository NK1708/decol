<?php
	
//Exir if access directly
if(!defined('ABSPATH')){
	exit;
}



?>